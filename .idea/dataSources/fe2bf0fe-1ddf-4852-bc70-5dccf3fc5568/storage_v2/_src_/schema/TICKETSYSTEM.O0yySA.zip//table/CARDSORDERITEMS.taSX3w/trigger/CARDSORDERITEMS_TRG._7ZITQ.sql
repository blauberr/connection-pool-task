create trigger CARDSORDERITEMS_TRG
  before insert
  on CARDSORDERITEMS
  for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;

/

