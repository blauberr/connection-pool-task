create PROCEDURE DBUPDATE_END 
(
  VERSIONNAME IN VARCHAR2 
) AS
BEGIN
  -- write version update end information
  UPDATE DBVERSIONS SET STATUS=2 WHERE NAME=VERSIONNAME AND STATUS=1;
  IF SQL%ROWCOUNT <> 1 THEN
    raise_application_error (-30002, 'Version update failed.');
  END IF;
  
  COMMIT;
END DBUPDATE_END;
/

