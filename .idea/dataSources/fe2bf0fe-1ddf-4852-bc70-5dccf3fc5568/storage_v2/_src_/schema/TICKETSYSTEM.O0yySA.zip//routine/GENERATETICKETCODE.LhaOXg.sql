create FUNCTION GENERATETICKETCODE 
(
  ticketid IN NUMBER
, ticketvalue IN NUMBER
, ticketyear IN NUMBER 
) RETURN VARCHAR2 AS
  codeyear NUMBER;
  ticketprefix CONSTANT NUMBER := 32;
  tickettype CONSTANT NUMBER := 1;  
  paddedticketid VARCHAR2(9);
  paddedticketvalue VARCHAR2(5);  
  paddedidandvalue VARCHAR2(14);
  codes1 NUMBER := 0;
  codes2 NUMBER := 0;
  codesum NUMBER := 0;
  check1 NUMBER;
  check2 NUMBER;
  partialcode VARCHAR2(21);
  sum2of5E NUMBER := 0;
  sum2of5O NUMBER := 0;
  sum2of5 NUMBER;
  control NUMBER;  
BEGIN
  IF ticketyear > 2000 THEN 
    codeyear := ticketyear - 2000;
  ELSE
    codeyear := ticketyear;
  END IF;

  paddedticketid := LPAD(ticketid, 9, 0);
  paddedticketvalue := LPAD(ticketvalue, 5, 0);
  paddedidandvalue := CONCAT(paddedticketid, paddedticketvalue);

  FOR j IN 0..6 LOOP    
    codes1 := codes1 + NVL(NULLIF(TO_NUMBER(SUBSTR(paddedidandvalue, j * 2 + 1, 1)), 0), 19) * NVL(NULLIF(TO_NUMBER(SUBSTR(paddedidandvalue, j * 2 + 2, 1)), 0), 19);
  END LOOP;
  
  codes1 := codes1 * codes1;  
  codes2 := ticketprefix + codeyear + tickettype + ticketid + ticketvalue;
  codes2 := codes2 * codes2;  
  codesum := codes1 + codes2;
  
  check1 := FLOOR(MOD(codesum, 853) / 100);
  check2 := MOD(MOD(codesum, 853), 10);
  
  partialcode := ticketprefix || codeyear || tickettype || paddedticketid || check1 || paddedticketvalue || check2;
    
  FOR j IN 1..21 LOOP
    IF MOD(j, 2)=1 THEN
      sum2of5O := sum2of5O + TO_NUMBER(SUBSTR(partialcode, j, 1));    
    ELSE
      sum2of5E := sum2of5E + TO_NUMBER(SUBSTR(partialcode, j, 1));
    END IF;
  END LOOP;
  
  sum2of5 := sum2of5O * 3 + sum2of5E;  
  control := MOD((FLOOR(sum2of5 / 10) + 1) * 10 - sum2of5, 10);
 
  RETURN CONCAT(partialcode, control);
END GENERATETICKETCODE;
/

