create trigger CARDS_TRG1
  before insert
  on CARDS
  for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;

/

