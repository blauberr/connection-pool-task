create trigger TICKETENVELOPES_TRG
  before insert
  on TICKETENVELOPES
  for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;

/

